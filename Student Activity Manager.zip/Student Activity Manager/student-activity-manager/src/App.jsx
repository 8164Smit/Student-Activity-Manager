import React, { useState } from "react";
import StudentForm from "./components/StudentForm";
import StudentList from "./components/StudentList";
import { layout } from "./layout/layout";

export default function App() {
  const [students, setStudents] = useState([]);

  function addStudent(name) {
    if (!name.trim()) return;
    const newStudent = {
      id: Date.now().toString(),
      name: name.trim(),
      detailsOpen: false,
      status: "absent",
    };
    setStudents((prev) => [newStudent, ...prev]);
  }

  function deleteStudent(id) {
    setStudents((prev) => prev.filter((s) => s.id !== id));
  }

  function toggleDetails(id) {
    setStudents((prev) =>
      prev.map((s) =>
        s.id === id ? { ...s, detailsOpen: !s.detailsOpen } : s
      )
    );
  }

  function markStatus(id, status) {
    setStudents((prev) =>
      prev.map((s) => (s.id === id ? { ...s, status } : s))
    );
  }

  return (
    <div style={layout.container}>
      <div style={layout.card}>
        <h1 style={layout.title}>Student Activity Manager</h1>

        <StudentForm onAdd={addStudent} />

        <div style={layout.summary}>
          <div>Total Students: {students.length}</div>
          <div>Present: {students.filter((s) => s.status === "present").length}</div>
          <div>Absent: {students.filter((s) => s.status === "absent").length}</div>
        </div>

        <StudentList
          students={students}
          onDelete={deleteStudent}
          onToggle={toggleDetails}
          onMark={markStatus}
        />
      </div>
    </div>
  );
}
