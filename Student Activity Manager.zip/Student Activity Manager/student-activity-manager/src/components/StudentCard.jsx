import React from "react";
import { layout } from "../layout/layout";

export default function StudentCard({ student, onDelete, onToggle, onMark }) {
    return (
        <div style={layout.cardItem}>
            <div style={layout.cardHeader}>
                <div>
                    <strong>{student.name}</strong>
                </div>

                <div style={layout.headerBtns}>
                    <button
                        onClick={() =>
                            onMark(student.id, student.status === "present" ? "absent" : "present")
                        }
                        style={layout.smallBtn}
                    >
                        {student.status === "present" ? "Mark Absent" : "Mark Present"}
                    </button>

                    <button onClick={() => onToggle(student.id)} style={layout.smallBtn}>
                        {student.detailsOpen ? "Hide" : "Details"}
                    </button>

                    <button onClick={() => onDelete(student.id)} style={layout.deleteBtn}>
                        Delete
                    </button>
                </div>
            </div>

            {student.detailsOpen && (
                <div style={layout.details}>
                    <div>ID: {student.id}</div>
                    <div>Status: {student.status}</div>

                    <div>Actions:</div>
                    <div style={layout.actionRow}>
                        <button
                            onClick={() => onMark(student.id, "present")}
                            style={layout.actionBtn}
                        >
                            Present
                        </button>
                        <button
                            onClick={() => onMark(student.id, "absent")}
                            style={layout.actionBtn}
                        >
                            Absent
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
}
