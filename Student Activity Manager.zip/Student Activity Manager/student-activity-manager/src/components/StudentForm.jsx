import React, { useRef, useState, Fragment } from "react";
import { layout } from "../layout/layout";

export default function StudentForm({ onAdd }) {
    const inputRef = useRef(null);
    const [name, setName] = useState("");

    function handleSubmit(e) {
        e.preventDefault();
        onAdd(name);
        setName("");
        inputRef.current.focus();
    }

    return (
        <Fragment>
            <form onSubmit={handleSubmit} style={layout.form}>
                <input
                    ref={inputRef}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Enter student name"
                    style={layout.input}
                />

                <div style={layout.buttons}>
                    <button type="submit" style={layout.addBtn}>
                        Add Student
                    </button>
                    <button
                        type="button"
                        onClick={() => {
                            setName("");
                            inputRef.current.focus();
                        }}
                        style={layout.clearBtn}
                    >
                        Reset
                    </button>
                </div>
            </form>
        </Fragment>
    );
}
