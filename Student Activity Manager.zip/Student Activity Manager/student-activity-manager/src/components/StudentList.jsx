import React from "react";
import StudentCard from "./StudentCard";
import { layout } from "../layout/layout";

export default function StudentList({ students, onDelete, onToggle, onMark }) {
    if (!students.length)
        return <div style={layout.empty}>No Students Found</div>;

    return (
        <div>
            {students.map((student) => (
                <StudentCard
                    key={student.id}
                    student={student}
                    onDelete={onDelete}
                    onToggle={onToggle}
                    onMark={onMark}
                />
            ))}
        </div>
    );
}
