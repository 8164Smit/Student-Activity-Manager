export const layout = {
    container: {
        height: "100%",      
        minHeight: "100vh",  
        display: "flex",
        alignItems: "center",  
        justifyContent: "center", 
        background: "#f5f7fb",
        padding: 20,
    },


    card: {
        width: 720,
        background: "#fff",
        padding: 24,
        margin: "0 auto",
        borderRadius: 8,
        boxShadow: "0 6px 18px rgba(20,20,40,0.06)",
    },

    title: { fontSize: 26, margin: "0 0 12px 0" },

    form: { display: "flex", gap: 12, marginBottom: 12, alignItems: "center" },
    input: {
        flex: 1,
        padding: "10px 12px",
        borderRadius: 6,
        border: "1px solid #ddd",
        fontSize: 14,
    },

    buttons: { display: "flex", gap: 8 },
    addBtn: {
        padding: "10px 14px",
        borderRadius: 6,
        border: "none",
        cursor: "pointer",
        background: "#0b74ff",
        color: "#fff",
    },
    clearBtn: {
        padding: "10px 12px",
        borderRadius: 6,
        border: "1px solid #ddd",
        cursor: "pointer",
        background: "#fff",
    },

    summary: {
        display: "flex",
        gap: 16,
        padding: "12px 0",
        borderTop: "1px solid #eee",
        borderBottom: "1px solid #eee",
        margin: "12px 0",
    },

    empty: { padding: 24, textAlign: "center", color: "#666" },

    cardItem: {
        padding: 12,
        borderRadius: 6,
        border: "1px solid #eee",
        marginBottom: 12,
        background: "#fafafa",
    },

    cardHeader: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
    },

    headerBtns: { display: "flex", gap: 8, alignItems: "center" },

    smallBtn: {
        padding: "6px 8px",
        borderRadius: 6,
        border: "1px solid #ccc",
        background: "#fff",
        cursor: "pointer",
    },

    deleteBtn: {
        padding: "6px 8px",
        borderRadius: 6,
        border: "none",
        background: "#ff5c5c",
        color: "#fff",
        cursor: "pointer",
    },

    details: {
        marginTop: 8,
        paddingTop: 8,
        borderTop: "1px dashed #e6e6e6",
        fontSize: 13,
    },

    actionRow: { display: "flex", gap: 8, marginTop: 8 },
    actionBtn: {
        padding: "6px 8px",
        borderRadius: 6,
        border: "1px solid #ccc",
        background: "#fff",
        cursor: "pointer",
    },
};
